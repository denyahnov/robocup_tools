# RoboCup.py

Use `ExampleProject()` to see usage of the wrapper

- `Clamper` (Motor Speeds, Sensor Values, etc)
- `FilteredSensor` (Averages values for accurate data)
- `PID_Controller` (Simple PID Controller)
- `Robot` (Easy to setup robot class with many features)
- `Driver` (HiTechnic Sensor Driver Names)
